package com.practice.task;

import java.util.*;

public class PracticeProjectFive {

	public static void main(String[] args) {
		 System.out.println("ArrayList Implementation:");
	        ArrayList<String> arrayList = new ArrayList<>();
	        arrayList.add("Apple");
	        arrayList.add("Banana");
	        arrayList.add("Cherry");
	        arrayList.add("Date");
	        for (String fruit : arrayList) {
	            System.out.println(fruit);
	        }
	        
	     // HashMap
	        System.out.println("\nHashMap Implementation:");
	        HashMap<Integer, String> hashMap = new HashMap<>();
	        hashMap.put(1, "One");
	        hashMap.put(2, "Two");
	        hashMap.put(3, "Three");
	        hashMap.put(4, "Four");

	        // Iterating and displaying key-value pairs
	        for (int key : hashMap.keySet()) {
	            System.out.println("Key: " + key + ", Value: " + hashMap.get(key));
	        }
	        
	        // HashSet
	        System.out.println("\nHashSet Implementation:");
	        HashSet<String> hashSet = new HashSet<>();
	        hashSet.add("Apple");
	        hashSet.add("Banana");
	        hashSet.add("Cherry");
	        hashSet.add("Date");

	        // Iterating and displaying unique elements
	        for (String fruit : hashSet) {
	            System.out.println(fruit);
	        }
	        
	        //LinkedList
	        System.out.println("\nLinkedList Implementation:");
	        LinkedList<String> linked = new LinkedList<>();
	        linked.add("Pravin");
	        linked.add("Gorakh");
	        for (String fruits : linked) {
	            System.out.println(fruits);
	        }
	        

	}

}
