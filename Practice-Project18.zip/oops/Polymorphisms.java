package com.task.two.oops;


class AnimalOne {
    public void makeSound() {
        System.out.println("Some generic animal sound");
    }
}


class DogOne extends AnimalOne {
    @Override
    public void makeSound() {
        System.out.println("Bark! Bark!");
    }
}

class CatOne extends AnimalOne {
    @Override
    public void makeSound() {
        System.out.println("Meow! Meow!");
    }
}

public class Polymorphisms {
    public static void main(String[] args) {
        
        AnimalOne myDog = new DogOne();
        AnimalOne myCat = new CatOne();

        
        myDog.makeSound(); 
        myCat.makeSound(); 
    }
}
