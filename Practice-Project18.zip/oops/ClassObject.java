package com.task.two.oops;

public class ClassObject {
	
	public void demo() {
		System.out.println("Hello Worlds!");
	}
	public static void main(String[] args) {
		ClassObject obj=new ClassObject();
		obj.demo();
	}
}
