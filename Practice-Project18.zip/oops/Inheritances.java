package com.task.two.oops;


class Animal{
	void animals() {
		System.out.println("This is animal class");
	}
}
class Dog extends Animal {
	void dogs() {
		System.out.println("This is Dog class");
	}
}

class Cat extends Dog{
	void cats() {
		System.out.println("This is cat class");
	}
}
public class Inheritances {
	
	public static void main(String[] args) {
		Cat obj=new Cat();
		obj.animals();
		obj.dogs();
		obj.cats();
	}
}
