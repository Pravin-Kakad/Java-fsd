package com.practice.task;

import java.util.HashMap;
import java.util.*;

public class Maps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// HashMap
        System.out.println("\nHashMap Implementation:");
        HashMap<Integer, String> hashMap = new HashMap<>();
        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");
        hashMap.put(4, "Four");

        // Iterating and displaying key-value pairs
        for (int key : hashMap.keySet()) {
            System.out.println("Key: " + key + ", Value: " + hashMap.get(key));
        }
        
     // HashTable
        System.out.println("\nHashTable Implementation:");
        Hashtable<Integer, String> hashtable = new Hashtable<>();
        hashtable.put(101, "Rohit");
        hashtable.put(102, "Ramesh");
        hashtable.put(103, "PK");;

        // Iterating and displaying key-value pairs
        for (int keys : hashtable.keySet()) {
            System.out.println("Key: " + keys + ", Value: " + hashtable.get(keys));
        }
        
     // TreeMap
        System.out.println("\nTreeMap Implementation:");
        TreeMap<Integer, String> treemap = new TreeMap<>();
        treemap.put(101, "five");
        treemap.put(201, "six");
        treemap.put(301, "seven");;

        // Iterating and displaying key-value pairs
        for (int keys : treemap.keySet()) {
            System.out.println("Key: " + keys + ", Value: " + treemap.get(keys));
        }

	}

}
