package com.practice.task;


public class PracticeProjectTwo {
	String def="Default";
	public String publicString="Public";
	private String privateString="private";
	protected String protectedString="protected";
	
	private void privateMethod() {
		System.out.println("Inside the private method");
	}
	
	public void publicMethod() {
		System.out.println("Inside the public method");
	}
	
	protected void protectedMethod() {
		System.out.println("Inside the protected method");
	}
	void defaultMethod() {
		System.out.println("Inside the default method");
	}

	public static void main(String[] args) {
		
		PracticeProjectTwo obj=new PracticeProjectTwo();
		System.out.println(obj.def);
		System.out.println(obj.publicString);
		System.out.println(obj.privateString);
		System.out.println(obj.protectedString);
		obj.privateMethod();
		obj.publicMethod();
		obj.protectedMethod();
		obj.defaultMethod();
	}

}
