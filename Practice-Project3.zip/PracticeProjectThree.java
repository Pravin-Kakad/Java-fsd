package com.practice.task;

public class PracticeProjectThree {
	
	public void demoMethod() {
		System.out.println("This is a demo method");
	}
	public void addition() {
		int a=5;
		int b=6;
		int result;
		result=a+b;
		System.out.println("Addition of two number is: "+result);
	}
	public void area(int r) {
		System.out.println("Area of circle is: "+(3.14*r));
	}
	public void area(int b, int h) {
		System.out.println("Area of triangle is: "+(0.5*b*h));
	}

	public static void main(String[] args) {
		PracticeProjectThree obj=new PracticeProjectThree();
		obj.demoMethod();
		obj.addition();
		obj.area(3);
		obj.area(3, 4);
	}

}
