package com.task.two.pp1;


class MyRunnable implements Runnable{
	 public void run() {
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Thread (implementing Runnable) - Count: " + i);
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                System.out.println(e);
	            }
	        }
	    }
}




public class Runnables  {
	public static void main(String[] args) {
        MyRunnable myRunnable = new MyRunnable();
        Thread thread2 = new Thread(myRunnable);
        thread2.start(); // Start the thread

        // Main thread
        for (int i = 1; i <= 5; i++) {
            System.out.println("Main Thread - Count: " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

}
