package com.task.two.pp1;

public class Threads extends Thread {
	public void run() {
		System.out.println("This is a threads");
	}
	public static void main(String[] args) {
		Threads obj=new Threads();
		obj.run();
	}
}
