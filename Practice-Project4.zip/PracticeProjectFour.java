package com.practice.task;

public class PracticeProjectFour {
	public PracticeProjectFour() {
		System.out.println("This default constructor.");
	}
	public PracticeProjectFour(int num1,int num2) {
		System.out.println("This is parameterized Constructor");
		System.out.println("Addition of two number: "+(num1+num2));
	}

	public static void main(String[] args) {
		PracticeProjectFour obj=new PracticeProjectFour();
		PracticeProjectFour obj1=new PracticeProjectFour(5,6);

	}

}
