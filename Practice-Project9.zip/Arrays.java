package com.practice.task;

public class Arrays {

	public static void main(String[] args) {
		 // Declare and initialize an array of integers
        int[] array = {10, 20, 30, 40, 50};

        // Display the array elements
        System.out.println("Array Elements:");
        for (int i = 0; i < array.length; i++) {
            System.out.println("Element " + i + ": " + array[i]);
        }
        
        
        int sum=0;
        for(int i=0;i<array.length;i++) {
        	sum=sum+array[i];
        }
        System.out.println("\nAddition of all elements are: "+sum);
        
        System.out.println("\nArray length is: "+array.length);
	}

}

