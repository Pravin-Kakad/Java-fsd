package com.practice.task;

public class InnerClasses {
	
	public class InsideClass{
		public void demoMethod() {
			int number=5;
			System.out.println("Square is: "+(number*number));
		}
	}

	public static void main(String[] args) {
		InnerClasses innerClassesobj=new InnerClasses();
		InnerClasses.InsideClass obj=innerClassesobj.new InsideClass();
		obj.demoMethod();

	}

}
