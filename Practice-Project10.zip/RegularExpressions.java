package com.practice.task;

import java.util.regex.*;

public class RegularExpressions {

	public static void main(String[] args) {
		// Sample text
		String text = "The quick brown fox jumps over the lazy dog. 123-456-7890 is a phone number. Email: example@example.com";

		// Define a regular expression pattern
		// Matches email addresses
		String pattern = "\\b(\\w+)@([\\w.]+)\\b"; 

		// Compile the pattern
		Pattern compiledPattern = Pattern.compile(pattern);

		// Create a matcher for the input text
		Matcher matcher = compiledPattern.matcher(text);

		// Find and display matches
		System.out.println("Matching Results:");
		while (matcher.find()) {
			String matchedText = matcher.group();
			String group1 = matcher.group(1);
			String group2 = matcher.group(2); 
			System.out.println("Matched Text: " + matchedText);
			System.out.println("Username: " + group1);
			System.out.println("Domain: " + group2);
		}

		// Other Way
		System.out.println();
		String patterns="[a-z]+";
		String check="Regular Expressition";
		Pattern p=Pattern.compile(patterns);
		Matcher c=p.matcher(check);
		while(c.find()) {
			System.out.println(check.substring(c.start(), c.end()));
		}

	}

}
