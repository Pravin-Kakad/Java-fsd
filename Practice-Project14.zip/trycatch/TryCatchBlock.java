package com.task.two.trycatch;

public class TryCatchBlock {
public static void main(String[] args) {
	
	System.out.println("Before try catch block");
    try {
      int divideByZero = 5 / 0;
      System.out.println("Rest of code in try block");
    }

    catch (ArithmeticException e) {
      System.out.println("ArithmeticException => " + e.getMessage());
    }
    System.out.println("After the try catch block");
}
}
