package com.task.two.FileCRUDDemo;
import java.io.*;

public class FileCRUD {

	// Create a new file
	public static void createFile(String filename) {
		try {
			File file = new File(filename);
			if (file.createNewFile()) {
				System.out.println("File created: " + file.getName());
			} else {
				System.out.println("File already exists.");
			}
		} catch (IOException e) {
			System.err.println("An error occurred while creating the file: " + e.getMessage());
		}
	}

	// Write data to the file
	public static void writeToFile(String filename, String data) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
			writer.write(data);
			System.out.println("Data written to the file.");
		} catch (IOException e) {
			System.err.println("An error occurred while writing to the file: " + e.getMessage());
		}
	}

	// Read data from the file
	public static String readFromFile(String filename) {
		StringBuilder content = new StringBuilder();
		try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
			String line;
			while ((line = reader.readLine()) != null) {
				content.append(line).append("\n");
			}
		} catch (IOException e) {
			System.err.println("An error occurred while reading from the file: " + e.getMessage());
		}
		return content.toString();
	}

	// Update the file
	public static void updateFile(String filename, String newData) {
		writeToFile(filename, newData);
		System.out.println("File updated.");
	}


	// Delete the file
	public static void deleteFile(String filename) {
		File file = new File(filename);
		if (file.delete()) {
			System.out.println("File deleted: " + file.getName());
		} else {
			System.out.println("Failed to delete the file.");
		}
	}


	public static void main(String[] args) {
		String filename = "example.txt";

		// Create a new file
		createFile(filename);

		// Write data to the file
		writeToFile(filename, "Hello, World!");

		// Read data from the file
		String content = readFromFile(filename);
		System.out.println("File Contents: " + content);

		// Update the file
		updateFile(filename, "Updated content.");

		// Read the updated data
		content = readFromFile(filename);
		System.out.println("Updated File Contents: " + content);

		// Delete the file
		deleteFile(filename);
	}
}
