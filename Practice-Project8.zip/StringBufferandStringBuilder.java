package com.practice.task;

public class StringBufferandStringBuilder {

	public static void main(String[] args) {
		 // Create a String
        String str = "Hello, World!";
        System.out.println("Original String: " + str);
        
        //length
        System.out.println("Length of string is: "+str.length());
        
        //String Comparison
        String s1="Hello";
        String s2="Hello";
        System.out.println("Comparison of two string: "+s1.compareTo(s2));
        
        //ToUppercase
        String s3="hello world!";
        System.out.println("String convert to uppercase is: "+s3.toUpperCase());
        
      //ToLowercase
        String s4="Hello World!";
        System.out.println("String convert to lowercase is: "+s3.toLowerCase());
        
        //Equals
        String s5="Hello";
        String s6="Hello";
        System.out.println("String equals or not check:"+s5.equals(s6));

        // Convert String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("String converted to StringBuffer: " + stringBuffer);

        // Convert String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("String converted to StringBuilder: " + stringBuilder);

	}

}

