package com.practice.task;

public class PracticeProjectOne {

	public static void main(String[] args) {
		int intNumber = 100;
		float floatNumber = intNumber;
		double doubleNumber=intNumber;

		System.out.println("Implicit Type Casting:");
		System.out.println("int value: " + intNumber);
		System.out.println("float value: " + floatNumber);
		System.out.println("float value: " + doubleNumber);

		
		float floatValue = 123.456f;
		int intValue = (int) floatValue;

		System.out.println("\nExplicit Type Casting:");
		System.out.println("float value: " + floatValue);
		System.out.println("int value: " + intValue);

	}

}


