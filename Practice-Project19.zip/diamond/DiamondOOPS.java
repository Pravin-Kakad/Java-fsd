package com.task.two.diamond;



interface Animal {
 void sound();
}

interface Dog extends Animal {
 void bark();
}




class Pet implements Dog {
 @Override
 public void sound() {
     System.out.println("Generic pet sound ");
 }

 @Override
 public void bark() {
     System.out.println("Pet dog barks");
 }

}

public class DiamondOOPS {
 public static void main(String[] args) {
     Pet pet = new Pet();

     pet.sound(); 
     pet.bark(); 
 }
}
